//
//  CountryCell.swift
//  AylaInterviewTask
//
//  Created by NRN on 04/12/23.
//

import UIKit

class CountryCell: UITableViewCell {

    
    @IBOutlet weak var countryImg: UIImageView!
    
    @IBOutlet weak var countryTitle: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
