//
//  CountryViewModel.swift
//  AylaInterviewTask
//
//  Created by NRN on 04/12/23.
//

import Foundation
import RxSwift

struct CountryViewModel {
    let title: String
    let description: String
    let imageUrl: String
}

class CountryListViewModel {
    private let disposeBag = DisposeBag()
    
    // Observable for the table view data
    var countries: Observable<[CountryViewModel]> {
        return countrySubject.asObservable()
    }
    
    private let countrySubject = BehaviorSubject<[CountryViewModel]>(value: [])
    
    func fetchCountryData() {
        // Fetch data from the API
        // Use Alamofire, URLSession, or any other networking library to make the request
        // Parse the JSON response and update the countrySubject
        // For brevity, we'll assume you have a function `fetchDataFromAPI()` that returns an Observable<[CountryViewModel]>
        
        fetchDataFromAPI()
            .bind(to: countrySubject)
            .disposed(by: disposeBag)
    }
    
    private func fetchDataFromAPI() -> Observable<[CountryViewModel]> {
        // Implement your API call here
        // You can use Alamofire, URLSession, or any other networking library
        // Return an Observable<[CountryViewModel]> after parsing the response
        
        // Example using URLSession
        return Observable.create { observer in
            URLSession.shared.dataTask(with: URL(string: "https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json")!) { data, response, error in
                guard let data = data, error == nil else {
                    observer.onError(error ?? NSError(domain: "Error", code: 0, userInfo: nil))
                    return
                }
            
                do {
                    let countryData = try JSONDecoder().decode(CountryData.self, from: data)
                    let countryViewModels = countryData.rows.map { CountryViewModel(title: $0.title, description: $0.description ?? "", imageUrl: $0.imageHref ?? "") }
                    observer.onNext(countryViewModels)
                    observer.onCompleted()
                } catch {
                    observer.onError(error)
                }
            }.resume()
            
            return Disposables.create()
        }
    }
}

