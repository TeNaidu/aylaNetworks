//
//  ViewController.swift
//  AylaInterviewTask
//
//  Created by NRN on 04/12/23.
//

import UIKit
import RxSwift
import RxCocoa

class ViewController: UIViewController, UIScrollViewDelegate {

    
    
    @IBOutlet weak var tableView: UITableView!
    
    private let viewModel = CountryListViewModel()
    private let disposeBag = DisposeBag()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        bindViewModel()
        viewModel.fetchCountryData()
    }

    private func setupTableView() {
          tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
      }
      
      private func bindViewModel() {
    
          viewModel.countries
              .observeOn(MainScheduler.instance)
              .bind(to: tableView.rx.items(cellIdentifier: "Cell")) { index, model, cell in
                  
                  if let customCell = cell as? CountryCell {
                      
                      customCell.countryTitle.text = model.title
                      print(customCell.countryTitle.text = model.title)
                      
                  }
                  
//                  cell.textLabel?.text = model.title
//                  cell.detailTextLabel?.text = model.description
                  
//                  if let imageUrl = URL(string: model.imageUrl) {
//                      cell.imageView?.kf.setImage(with: imageUrl)
//                  }
              }
              .disposed(by: disposeBag)
      }
  

}

