//
//  CountryData.swift
//  AylaInterviewTask
//
//  Created by NRN on 04/12/23.
//

import Foundation

struct CountryData: Codable {
    let title: String
    let rows: [Country]
}

struct Country: Codable {
    let title: String
    let description: String?
    let imageHref: String?
}

